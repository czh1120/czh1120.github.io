<!DOCTYPE html>
<html lang="zh-Hant">
<head>
  <meta charset="UTF-8">
  <title>F1 簡介網站</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    nav {
      background-color: #0d7dba;
      padding: 10px;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    nav ul {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
    }

    nav li {
      position: relative;
      margin-right: 30px;
    }

    nav a {
      color: white;
      text-decoration: none;
      padding: 10px 15px;
      display: block;
    }

    .submenu {
      display: none;
      position: absolute;
      background-color: #333;
      top: 100%;
      left: 0;
      min-width: 150px;
      z-index: 10;
    }

    .submenu a {
      padding: 10px;
      color: #fff;
      white-space: nowrap;
    }

    nav li:hover .submenu {
      display: block;
    }

    section {
      padding: 40px 20px;
    }

    h2 {
      border-bottom: 2px solid #ccc;
      padding-bottom: 10px;
    }
  </style>
</head>
<body>

  <!-- 導覽列 -->
  <nav>
    <ul>
      <li><a href="#intro">基本介紹</a></li>
      <li>
          <a href="#team1">車隊簡介</a>
        <ul class="submenu">
          <li><a href="#team1">Red Bull</a></li>
          <li><a href="#team2">Mercedes</a></li>
          <li><a href="#team3">Ferrari</a></li>
          <li><a href="#team4">McLaren</a></li>
          <li><a href="#team5">Aston Martin</a></li>
          <li><a href="#team6">Alpine</a></li>
          <li><a href="#team7">Williams</a></li>
          <li><a href="#team8">Kick Sauber</a></li>
          <li><a href="#team9">Haas</a></li>
          <li><a href="#team10">RB</a></li>
        </ul>
      </li>
      <li>
        <a href="#driver1">我喜歡的</a>
        <ul class="submenu">
          <li><a href="#driver1">Carlos Sainz</a></li>
          <li><a href="#driver2">Kimi Antonelli</a></li>
          <li><a href="#driver3">Charles Leclerc</a></li>
          <li><a href="#driver4">Max Verstappen</a></li>
          <li><a href="#driver5">Toto Wolff</a></li>
        </ul>
      </li>
    </ul>
  </nav>